package com.ihg.app.pages;

import com.accenture.test.ui.WebDriverSession;

public class IhgPage extends WebDriverSession {

	public void IhgPage() {
		PageFactory.initElements(getWebDriverSession(), this);
	}
	@FindBy(css = "#book input.form-control.searchbox")
	public WebElement Destinations;

	@FindBy(css = "<#book input.form-control.adults")
	public WebElement adultos;
	public WebElement destination;

	public void setDestination() {
    destination.clear();
    destination.click();
//   destination.getAttribute("");
	}
	  public void setAdultos( ) {
		  
		  adultos.clear();
		  adultos.getText();
		  adultos.getTagName();
		  adultos.isSelected();
	  }
//PUBLIC STATIC VOID MAIN(STRING[] ARGS) {
//	// TODO AUTO-GENERATED METHOD STUB
//
//}

}}

